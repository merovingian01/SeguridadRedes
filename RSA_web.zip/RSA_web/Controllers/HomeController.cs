using Microsoft.AspNetCore.Mvc;
using Npgsql;
using RSA_web.Models;
using System.Diagnostics;
using System;
using System.Linq;

namespace RSA_web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }



        [HttpPost]
        public JsonResult Login(string email, string psw_usuario)
        {
            bool checkUser = false;
            ConexionBD conexionBD = new ConexionBD();
            string query = "SELECT * FROM private.usuarios WHERE email= '" + email + "' AND psw_usuario= '" + psw_usuario + "'";
            NpgsqlCommand cmd = new NpgsqlCommand(query, conexionBD.Abrir_Conexion());

            using (NpgsqlDataReader lector = cmd.ExecuteReader())
            {
                if (lector.HasRows)
                {
                    while (lector.Read())
                    {
                        checkUser = true;
                    }
                }
            }
            string jsonResponse = "";

            if (checkUser == true)
            {
                jsonResponse = "{\"status\":200, \"data\":{\"user\":\"" + email + "\"}}";
            }
            else
            {
                jsonResponse = "{\"status\":500,\"data\":\"ERROR EL USUARIO NO EXISTE\"}";
            }
            return Json(jsonResponse);
        }
        public IActionResult Registrarse(string email, string psw_usuario)
        {
            try
            {
                InsertarNuevoUsuario(email, psw_usuario);
                var jsonResponse = "{\"status\":200, \"data\":{\"user\":\"" + email + "\"}}";
                return Content(jsonResponse, "application/json");
            }
            catch (Exception ex)
            {
                var errorResponse = "{\"status\":500, \"data\":\"ERROR: " + ex.Message.Replace("\"", "\\\"") + "\"}";
                return Content(errorResponse, "application/json");
            }
        }

        private void InsertarNuevoUsuario(string email, string psw_usuario)
        {
            ConexionBD conexionBD = new ConexionBD();

            // Consulta SQL para insertar el nuevo usuario
            string query = "INSERT INTO private.usuarios (email, psw_usuario) VALUES (@Email, @Password)";
            NpgsqlCommand cmd = new NpgsqlCommand(query, conexionBD.Abrir_Conexion());
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Password", psw_usuario);

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al insertar en la base de datos: {ex.Message}");
                throw;
            }
            finally
            {
                conexionBD.Cerrar_Conexion();
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}