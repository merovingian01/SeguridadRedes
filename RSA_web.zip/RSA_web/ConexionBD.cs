﻿using Npgsql;
namespace RSA_web
{
    public class ConexionBD
    {
        private NpgsqlConnection conn;

        public ConexionBD()
        {
            conn = new NpgsqlConnection("Server =localhost; Port=5432; User Id = postgres; Password=admin1234; Database=RSA");
        }

        public NpgsqlConnection Abrir_Conexion()
        {
            try
            {
                conn.Open();
                return conn;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public void Cerrar_Conexion()
        {
            conn.Close();
        }

    }
}
