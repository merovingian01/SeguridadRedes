﻿using System.Collections.Generic;

public class RSA
{
    public static List<int> Encrypt(List<int> data, int publicKeyE, int modulus)
    {
        List<int> result = new List<int>();
        foreach (int value in data)
        {
            result.Add(ModPow(value, publicKeyE, modulus));
        }
        return result;
    }

    private static int ModPow(int baseNum, int exponent, int modulus)
    {
        int result = 1;
        baseNum = baseNum % modulus;

        while (exponent > 0)
        {
            if (exponent % 2 == 1)
            {
                result = (result * baseNum) % modulus;
            }
            exponent = exponent >> 1;
            baseNum = (baseNum * baseNum) % modulus;
        }

        return result;
    }
}
